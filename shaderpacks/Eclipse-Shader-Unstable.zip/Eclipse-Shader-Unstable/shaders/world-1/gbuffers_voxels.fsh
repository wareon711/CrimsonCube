#version 430 compatibility


#define NETHER_SHADER

#include "/dimensions/voxels.fsh"