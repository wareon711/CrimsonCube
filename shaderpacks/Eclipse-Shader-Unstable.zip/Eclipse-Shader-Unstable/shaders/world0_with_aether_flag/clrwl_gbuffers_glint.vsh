
#version 430 compatibility

#define OVERWORLD_SHADER
#define AETHER_FLAG

#define ENCHANT_GLINT
#define COLORWHEEL

#include "/dimensions/all_vanilla_emissives.vsh"