#version 430 compatibility

#define BLOCKENTITIES
#define OVERWORLD_SHADER
#define AETHER_FLAG

#include "/dimensions/all_translucent.fsh"