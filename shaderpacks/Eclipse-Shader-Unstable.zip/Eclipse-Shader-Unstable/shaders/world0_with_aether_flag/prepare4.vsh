#version 430 compatibility

#define OVERWORLD_SHADER
#define AETHER_FLAG

#include "/dimensions/prepare4.vsh"