#version 430 compatibility

#define OVERWORLD_SHADER

#include "/dimensions/composite10.vsh"